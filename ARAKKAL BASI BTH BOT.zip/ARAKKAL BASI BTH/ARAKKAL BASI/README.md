# Kannapi-2.0 - bot
Simple WhatsApp Bot

### FOR TERMUX USER
```bash
> pkg update && pkg upgrade
> pkg install git
> pkg install nodejs
> pkg install ffmpeg
> pkg install imagemagick
> git clone https://github.com/mrravanan/kannapi-2.0.git
> cd kannapi-2.0
> npm install
```
###### Run
```bash
> node . [<session name>] (session name is optional)
```

---------

### FOR WINDOWS/VPS/RDP USER
```bash
> git clone https://github.com/mrravanan/kannapi-2.0.git
> cd kannapi-2.0
> npm install
```
###### Run
```bash
> node index.js
```
 SOSMED:
 
 Instagram: _king_of_dev._
 
 love only: devan
