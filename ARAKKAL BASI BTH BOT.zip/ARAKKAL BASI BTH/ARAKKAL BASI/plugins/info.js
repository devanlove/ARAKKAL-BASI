let handler  = async (m, { conn, usedPrefix: _p }) => {
  conn.reply(m.chat, `
╠═〘  ARAKKAL BASI BTH 〙 ═
╠➥  Made in javascript via NodeJs
╠➥ Rec: ARAKKAL BASI [BTH]
╠➥ Script: love only
║
╠➥ instagram: https://instagram.com/b__________t___________h?igshid=17zxu9l1yip58
╠
║
╠═〘 Thanks To 〙 ═
╠➥ devan 
╠➥ 
║
╠═〘 BLACK HACKER 〙 ═
╠➥ MAKE GROUP ADMIN 
╠➥ TURN ON YOUR DATA
╠➥ CONTACT : wa.me//+918891903813
║
║>Request? wa.me//+918891903813
║
╠═〘 BTH BOAT〙 ═
`.trim(), m)
}
handler.command = /^(info)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler

